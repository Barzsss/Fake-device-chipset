# 📱 Device & Chipset Changer + Remover (Final Real Version)
Script interaktif: ganti brand, device & chipset Android.
+ Real brand & real device terbaru, unreleased, concept
+ Remover (balik ke build.prop asli)
+ ASCII logo
+ Backup otomatis

## Cara pakai
```sh
chmod +x device_changer.sh
su -c ./device_changer.sh
```

⚠ Wajib root
✨ Credits: Created by @Barzsss
